Developed By Afride Hossain.
Check out his website https://afridehossain.github.io/afride_portfolio2/